package view;

public class StudentView {
	public void print(int id,String name,String address) {
		System.out.println("id"+id);
		System.out.println("name"+name);
		System.out.println("address"+address);
		System.out.println("----------");
		
	}
	
	

}
