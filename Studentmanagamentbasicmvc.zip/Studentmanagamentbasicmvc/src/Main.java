import controller.StudentController;
import Model.Student;
import view.StudentView;
public class Main {
    public static void main(String args[]) {
        Student model = new Student(66, "janani", "MRKP");
        StudentView view = new StudentView();
        StudentController controller = new StudentController(model, view);
        controller.displayStudent();
    }
}
