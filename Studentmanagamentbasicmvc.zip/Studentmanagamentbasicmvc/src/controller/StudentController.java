package controller;
import Model.Student;
import view.StudentView;
public class StudentController {
    private Student model;
    private StudentView view;
    public StudentController(Student model, StudentView view) {
        this.model = model;
        this.view = view;
    }
    public void displayStudent() {
        view.print(model.getId(), model.getName(), model.getAddress());
    }
}
